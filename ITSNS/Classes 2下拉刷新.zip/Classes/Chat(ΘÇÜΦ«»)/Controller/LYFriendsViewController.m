//
//  LYFriendsViewController.m
//  ITSNS
//
//  Created by Ivan on 16/1/10.
//  Copyright © 2016年 Ivan. All rights reserved.
//
#import "UIImageView+WebCache.h"
#import "TRReqeustsTableViewController.h"
#import "EaseMobManager.h"
#import "LYFriendsViewController.h"

@interface LYFriendsViewController ()<UITableViewDataSource ,UITableViewDelegate>
@property (nonatomic, strong)UITableView *tableView;
@property (nonatomic, strong)NSMutableArray *friends;
@end

@implementation LYFriendsViewController

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [self.tableView reloadData];
}
- (void)viewDidLoad {
    [super viewDidLoad];
    
    
    UITableView *tableView= [[UITableView alloc]initWithFrame:[UIScreen mainScreen].bounds style:UITableViewStylePlain];
    tableView.delegate = self;
    tableView.dataSource = self;
    
    [self.view addSubview:tableView];
    self.tableView = tableView;
    
    
    
    
    [self loadFirends];
    
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(loadFirends) name:@"新的好友通知" object:nil];
}

-(void)loadFirends{
    
    
    //加载好友列表
    [[EaseMob sharedInstance].chatManager asyncFetchBuddyListWithCompletion:^(NSArray *buddyList, EMError *error) {
        if (!error) {
            NSLog(@"获取成功 -- %@",buddyList);
            
            //创建数组 添加好友名称
            NSMutableArray *names = [NSMutableArray array];
            for (EMBuddy *buddy in buddyList) {
                NSString *userName = buddy.username;
                
                [names addObject:userName];
            }
            
            BmobQuery *query = [BmobQuery queryForUser];
            //设置查询条件
            [query whereKey:@"username" containedIn:names];
            
            [query findObjectsInBackgroundWithBlock:^(NSArray *array, NSError *error) {
                
                self.friends = [array mutableCopy];

                
                [self.tableView reloadData];
            }];

        }
    } onQueue:nil];
}




- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 2;
}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    if (section==0) {
        return 1;
    }
    
    return self.friends.count;
    
}



- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    UITableViewCell *cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"cell"];
    
    
    if (indexPath.section==0&&indexPath.row==0) {
        
        
        cell.textLabel.text = [NSString stringWithFormat:@"有%ld个好友请求",[EaseMobManager shareManager].requests.count];
    }else{
        BmobUser *user = self.friends[indexPath.row];
        
        cell.textLabel.text = [user objectForKey:@"nick"];
        
        [cell.imageView sd_setImageWithURL:[NSURL URLWithString:[user objectForKey:@"headPath"]] completed:^(UIImage *image, NSError *error, SDImageCacheType cacheType, NSURL *imageURL) {
            //刷新子控件显示
            [cell setNeedsLayout];
        }];
    }
    return cell;
    
    
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if (indexPath.section==0) {
        TRReqeustsTableViewController *vc = [TRReqeustsTableViewController new];
        
        [self.navigationController pushViewController:vc animated:YES];
    }
    
}


//删除好友
-(void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        //删除
        BmobUser *user = self.friends[indexPath.row];
        //服务器
        [[EaseMobManager shareManager]removeFirendWithName:user.username];
        //数据源
        [self.friends removeObject:user];
//        界面
        [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationFade];

        
        
    }
    
    
    
}

@end
