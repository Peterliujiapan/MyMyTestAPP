//
//  TRViewController.h
//  ITSNS
//
//  Created by tarena on 16/6/25.
//  Copyright © 2016年 Ivan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TRSendingViewController : UIViewController
@property (nonatomic, copy)NSString *type;
@end
