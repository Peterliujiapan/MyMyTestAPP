//
//  FaceView.h
//  表情键盘
//
//  Created by tarena on 16/6/20.
//  Copyright © 2016年 Tarena. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FaceView : UIView
@property (nonatomic, strong)NSArray *faceArr;
@end
