//
//  WeiboImageView.h
//  达内微博
//
//  Created by tarena on 16/5/10.
//  Copyright © 2016年 tarena. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "TRITObject.h"
#import "Comment.h"
@interface ImageBrowserView : UIView
@property (nonatomic, strong)TRITObject *itObj;
@property (nonatomic, strong)Comment *comment;


@end
