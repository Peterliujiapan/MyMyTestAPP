//
//  LYUserCell.h
//  ITSNS
//
//  Created by Ivan on 16/3/11.
//  Copyright © 2016年 Ivan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LYUserCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *unreadCount;
@property (nonatomic, strong)BmobUser *user;
@property (weak, nonatomic) IBOutlet UILabel *detailLabel;
@property (weak, nonatomic) IBOutlet UILabel *nameLabel;
@property (weak, nonatomic) IBOutlet UIImageView *headIV;

@end
