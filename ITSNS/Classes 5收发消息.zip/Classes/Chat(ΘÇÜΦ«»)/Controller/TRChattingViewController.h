//
//  TRChattingViewController.h
//  ITSNS
//
//  Created by tarena on 16/7/5.
//  Copyright © 2016年 Ivan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TRChattingViewController : UIViewController
@property (nonatomic, strong)BmobUser *toUser;
@end
