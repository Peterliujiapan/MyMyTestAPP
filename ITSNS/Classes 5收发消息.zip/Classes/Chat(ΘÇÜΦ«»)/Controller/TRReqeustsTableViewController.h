//
//  TRReqeustsTableViewController.h
//  ITSNS
//
//  Created by tarena on 16/7/4.
//  Copyright © 2016年 Ivan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TRReqeustsTableViewController : UITableViewController

@end
