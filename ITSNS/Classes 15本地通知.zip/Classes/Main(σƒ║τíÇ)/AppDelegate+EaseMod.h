//
//  AppDelegate+EaseMod.h
//  环信测试
//
//  Created by tarena on 16/7/2.
//  Copyright © 2016年 Tarena. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate (EaseMod)

-(void)initEaseMob:(UIApplication *)application andOptions:(NSDictionary *)dic;
@end
