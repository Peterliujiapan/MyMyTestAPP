//
//  AppDelegate+EaseMod.m
//  环信测试
//
//  Created by tarena on 16/7/2.
//  Copyright © 2016年 Tarena. All rights reserved.
//

#import "AppDelegate+EaseMod.h"
#import <EaseMob.h>
@implementation AppDelegate (EaseMod)


-(void)initEaseMob:(UIApplication *)application andOptions:(NSDictionary *)dic{
    
    //    如果使用通知 不管是本地通知还是远程推送 都需要注册一下
    UIUserNotificationType types = UIUserNotificationTypeAlert | UIUserNotificationTypeBadge | UIUserNotificationTypeSound;
    
    UIUserNotificationSettings *settings = [UIUserNotificationSettings settingsForTypes:types categories:nil];
    [[UIApplication sharedApplication] registerUserNotificationSettings:settings];
    
    
    
    
    
    //registerSDKWithAppKey: 注册的AppKey，详细见下面注释。
    //apnsCertName: 推送证书名（不需要加后缀），详细见下面注释。
    [[EaseMob sharedInstance] registerSDKWithAppKey:@"77331283#1603itsns" apnsCertName:nil];
    [[EaseMob sharedInstance] application:application didFinishLaunchingWithOptions:dic];
    
}

// APP进入后台
- (void)applicationDidEnterBackground:(UIApplication *)application
{
    [[EaseMob sharedInstance] applicationDidEnterBackground:application];
}

// APP将要从后台返回
- (void)applicationWillEnterForeground:(UIApplication *)application
{
    [[EaseMob sharedInstance] applicationWillEnterForeground:application];
}

// 申请处理时间
- (void)applicationWillTerminate:(UIApplication *)application
{
    [[EaseMob sharedInstance] applicationWillTerminate:application];
}
@end
