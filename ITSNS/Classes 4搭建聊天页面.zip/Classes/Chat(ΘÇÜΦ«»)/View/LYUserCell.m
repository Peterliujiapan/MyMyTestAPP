//
//  LYUserCell.m
//  ITSNS
//
//  Created by Ivan on 16/3/11.
//  Copyright © 2016年 Ivan. All rights reserved.
//

#import "LYUserCell.h"

@implementation LYUserCell

-(void)setUser:(BmobUser *)user{
    _user = user;
    self.nameLabel.text = [user objectForKey:@"nick"];
    self.detailLabel.text = user.username;
    [self.headIV sd_setImageWithURL:[NSURL URLWithString:[user objectForKey:@"headPath"]]];
}

@end
