//
//  TRPointAnnotation.m
//  ITSNS
//
//  Created by tarena on 16/7/1.
//  Copyright © 2016年 Ivan. All rights reserved.
//

#import "TRPointAnnotation.h"

@implementation TRPointAnnotation

@end
