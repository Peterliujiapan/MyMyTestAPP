//
//  EaseMobManager.m
//  环信测试
//
//  Created by tarena on 16/7/2.
//  Copyright © 2016年 Tarena. All rights reserved.
//

#import "EaseMobManager.h"
static EaseMobManager *_manager;
@implementation EaseMobManager
+(EaseMobManager *)shareManager{
    
    @synchronized(self) {
        
        if (!_manager) {
            _manager = [[EaseMobManager alloc]init];
          
            
            [[EaseMob sharedInstance].chatManager addDelegate:_manager delegateQueue:nil];
        }
        
    }
    return _manager;
    
}
- (instancetype)init
{
    self = [super init];
    if (self) {
          self.requests = [NSMutableArray array];
    }
    return self;
}
-(void)registerWithName:(NSString *)name andPW:(NSString *)pw andCallback:(MyCallback)callback{
    
    [[EaseMob sharedInstance].chatManager asyncRegisterNewAccount:name password:pw withCompletion:^(NSString *username, NSString *password, EMError *error) {
        if (!error) {
            NSLog(@"注册成功");
            callback(nil);
            
            //登录
            [[EaseMobManager shareManager]loginWithWithName:username andPW:username andCallback:^(id obj) {
                if ([obj isKindOfClass:[NSDictionary class]]) {
                    NSLog(@"登录成功");
                }else{
                    NSLog(@"登录失败");
                }
            }];
            
            
            
        }else{
            callback(error);
        }
        
    } onQueue:nil];
    
}

-(void)loginWithWithName:(NSString *)name andPW:(NSString *)pw andCallback:(MyCallback)callback{
    
    [[EaseMob sharedInstance].chatManager asyncLoginWithUsername:name password:pw completion:^(NSDictionary *loginInfo, EMError *error) {
        if (!error && loginInfo) {
            NSLog(@"登录成功");
            // 设置自动登录
            [[EaseMob sharedInstance].chatManager setIsAutoLoginEnabled:YES];
            callback(loginInfo);
            
        }else{
            callback(error);
        }
        
        
    } onQueue:nil];
    
}


-(void)addFirendWithName:(NSString *)name{
    
    
    EMError *error = nil;
    BOOL isSuccess = [[EaseMob sharedInstance].chatManager addBuddy:name message:@"我想加您为好友" error:&error];
    if (isSuccess && !error) {
        NSLog(@"添加成功");
    }
    
}

//删除好友
-(void)removeFirendWithName:(NSString *)name{
    
    EMError *error = nil;
    // 删除好友
    BOOL isSuccess = [[EaseMob sharedInstance].chatManager removeBuddy:name removeFromRemote:YES error:&error];
    if (isSuccess && !error) {
        NSLog(@"删除成功");
    }
    
}


//发送文本消息
-(EMMessage *)sendMessageWithText:(NSString *)text andToName:(NSString *)toName{
    
    //创建文本消息
    EMChatText *txtChat = [[EMChatText alloc] initWithText:text];
    EMTextMessageBody *body = [[EMTextMessageBody alloc] initWithChatObject:txtChat];
    
    // 生成message
    EMMessage *message = [[EMMessage alloc] initWithReceiver:toName bodies:@[body]];
    message.messageType = eMessageTypeChat; // 设置为单聊消息
    
    
    
    [[EaseMob sharedInstance].chatManager sendMessage:message progress:self error:nil];
    return message;
}

//发送图片消息
-(EMMessage *)sendMessageWithImage:(UIImage *)image andToName:(NSString *)toName{
    
    
    EMChatImage *imgChat = [[EMChatImage alloc] initWithUIImage:image displayName:@"a.jpg"];
    EMImageMessageBody *body = [[EMImageMessageBody alloc] initWithChatObject:imgChat];
    
    // 生成message
    EMMessage *message = [[EMMessage alloc] initWithReceiver:toName bodies:@[body]];
    message.messageType = eMessageTypeChat; // 设置为单聊消息
    
    [[EaseMob sharedInstance].chatManager sendMessage:message progress:self error:nil];
    return message;
    
    
    
}



//发送录音消息
-(EMMessage *)sendMessageWithVoiceData:(NSData *)data andTime:(NSNumber *)duration andToName:(NSString *)toName{
    
    
   
    EMChatVoice *voice = [[EMChatVoice alloc] initWithData:data displayName:@"a.amr"];
    voice.duration = [duration intValue];
    EMVoiceMessageBody *body = [[EMVoiceMessageBody alloc] initWithChatObject:voice];
    
    // 生成message
    EMMessage *message = [[EMMessage alloc] initWithReceiver:toName bodies:@[body]];
    message.messageType = eMessageTypeChat; // 设置为单聊消息
    
    
    
    
    
    [[EaseMob sharedInstance].chatManager sendMessage:message progress:self error:nil];
    return message;
    
    
    
}

#pragma mark 环信代理方法
- (void)didReceiveBuddyRequest:(NSString *)username
                       message:(NSString *)message{
    [self.requests addObject:username];
    
    
    
    [[NSNotificationCenter defaultCenter]postNotificationName:@"新的好友通知" object:nil];
    
    
}


- (void)didAcceptedByBuddy:(NSString *)username{
    
      NSString *myMessage = [NSString stringWithFormat:@"%@添加成功",username];
    UIAlertController *ac = [UIAlertController alertControllerWithTitle:@"提示" message:myMessage preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *action1 = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        
        [[NSNotificationCenter defaultCenter]postNotificationName:@"新的好友通知" object:nil];
        
        
        
    }];
    
    
    [ac addAction:action1];
  
    [[UIApplication sharedApplication].keyWindow.rootViewController presentViewController:ac animated:YES completion:nil];
}

- (void)didRejectedByBuddy:(NSString *)username{
    
    NSString *myMessage = [NSString stringWithFormat:@"%@拒绝了你的请求",username];
    UIAlertController *ac = [UIAlertController alertControllerWithTitle:@"提示" message:myMessage preferredStyle:UIAlertControllerStyleAlert];
    
    UIAlertAction *action1 = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:^(UIAlertAction * _Nonnull action) {
        
        //保存图片
    }];
    
    
    [ac addAction:action1];
    
    [[UIApplication sharedApplication].keyWindow.rootViewController presentViewController:ac animated:YES completion:nil];
    
    
}

- (void)didReceiveMessage:(EMMessage *)message{
    
    [[NSNotificationCenter defaultCenter]postNotificationName:@"接收到消息通知" object:message];
    
    
}

#pragma mark 发送进度delegate
- (void)setProgress:(float)progress
         forMessage:(EMMessage *)message
     forMessageBody:(id<IEMMessageBody>)messageBody{
    
    NSLog(@"进度：%f",progress);
    
}

@end
