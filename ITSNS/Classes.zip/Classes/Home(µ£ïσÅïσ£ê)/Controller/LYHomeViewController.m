//
//  LYHomeViewController.m
//  ITSNS
//
//  Created by Ivan on 16/1/9.
//  Copyright © 2016年 Ivan. All rights reserved.
//

#import "TRDetailViewController.h"
#import "LYHomeViewController.h"
#import "AppDelegate.h"
#import "LYHomeCell.h"
#import "TRITObject.h"

@interface LYHomeViewController ()<UITableViewDataSource,UITableViewDelegate>
@property (nonatomic, strong)NSArray *objs;
@property (nonatomic, strong)UITableView *tableView;




@end

@implementation LYHomeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.view.backgroundColor = [UIColor grayColor];
    
    UITableView *tableView = [[UITableView alloc]initWithFrame:[UIScreen mainScreen].bounds style:UITableViewStylePlain];
    
    [self.view addSubview:tableView];
    tableView.dataSource = self;
    tableView.delegate = self;
    self.tableView = tableView;
    
    [tableView registerNib:[UINib nibWithNibName:@"LYHomeCell" bundle:[NSBundle mainBundle]] forCellReuseIdentifier:@"cell"];
    
    
    [self loadMessages];
    
}



-(void)viewDidAppear:(BOOL)animated{
    
    [super viewDidAppear:animated];
    
    
    NSIndexPath *seletedIndexPath = [self.tableView indexPathForSelectedRow];
    
    
    if (seletedIndexPath) {
        //自己刷新数据
        //    LYHomeCell *cell = [self.tableView cellForRowAtIndexPath:seletedIndexPath];
        
        //    cell.itObj = self.objs[seletedIndexPath.row];
        
        //让tableView去刷新
        [self.tableView reloadRowsAtIndexPaths:@[seletedIndexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
        
        //取消选中效果
        [self.tableView deselectRowAtIndexPath:seletedIndexPath animated:YES];
    }

    
    
}

- (void)loadMessages{
    BmobQuery *query = [BmobQuery queryWithClassName:@"ITSNSObject"];
    
    //查询时如果有某个字段是bmobObject类型 需要查询时设置包含
    [query includeKey:@"user"];
    
    //设置查询条件  type = 0；
    
    [query whereKey:@"type" equalTo:self.type];
    
    
    
    //判断是否显示自己的信息
    if (self.showSelfInfo) {
        [query whereKey:@"user" equalTo:[BmobUser getCurrentUser]];
    }
    
    [query orderByDescending:@"createdAt"];
    
    [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    //执行查询请求
    [query findObjectsInBackgroundWithBlock:^(NSArray *array, NSError *error) {
        NSMutableArray *itObjs = [NSMutableArray array];
        for (BmobObject *bObj in array) {
            TRITObject *itObj = [[TRITObject alloc]initWithBmobObj:bObj];
            
            
            if ([itObj.title isEqualToString:@"location"]) {
                BmobGeoPoint *point = [bObj objectForKey:@"location"];
                NSLog(@"aaaa:%f--%f",point.longitude,point.latitude);
            }
            [itObjs addObject:itObj];
            
        }
        
        
        self.objs = itObjs;
        [self.tableView reloadData];
        
        [MBProgressHUD hideHUDForView:self.view animated:YES];
        
    }];
    

}
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    
    return self.objs.count;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    LYHomeCell *cell = [tableView dequeueReusableCellWithIdentifier:@"cell" forIndexPath:indexPath];
    
   
    
    cell.itObj = self.objs[indexPath.row];
  
    
 
    
    return cell;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    TRITObject *itObj = self.objs[indexPath.row];
    
    return 60+[itObj getHeigth];
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    // 通过点击的位置得到cell
    LYHomeCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    
   
    
    
    
    TRITObject *itObj = self.objs[indexPath.row];
    
    //让浏览量增加1
    [itObj addShowCountWithCompletionBlock:^(id obj) {
        
         cell.itObj = obj;
    }];
    
    
   
    
    
    
    TRDetailViewController *vc = [TRDetailViewController new];
    
    vc.itObj = itObj;
    
    
    [self.navigationController pushViewController:vc animated:YES];
    
    
}

@end
