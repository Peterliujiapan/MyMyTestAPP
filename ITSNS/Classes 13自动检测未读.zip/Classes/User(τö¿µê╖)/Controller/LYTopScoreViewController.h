//
//  LYTopScoreViewController.h
//  ITSNS
//
//  Created by Ivan on 16/1/22.
//  Copyright © 2016年 Ivan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LYTopScoreViewController : UIViewController

@end
