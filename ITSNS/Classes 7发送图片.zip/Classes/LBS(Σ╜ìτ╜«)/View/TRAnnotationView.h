//
//  TRAnnotationView.h
//  ITSNS
//
//  Created by tarena on 16/7/1.
//  Copyright © 2016年 Ivan. All rights reserved.
//

#import <BaiduMapAPI_Map/BMKMapComponent.h>

@interface TRAnnotationView : BMKAnnotationView
@property (nonatomic, strong)UIImageView *headIV;
@end
