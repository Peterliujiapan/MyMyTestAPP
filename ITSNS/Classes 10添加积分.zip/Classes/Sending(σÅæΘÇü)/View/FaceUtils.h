//
//  FaceUtils.h
//  表情键盘
//
//  Created by tarena on 16/6/20.
//  Copyright © 2016年 Tarena. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "YYTextView.h"
@interface FaceUtils : NSObject


+(void)faceBindingWithTextView:(YYTextView *)tv;
@end
