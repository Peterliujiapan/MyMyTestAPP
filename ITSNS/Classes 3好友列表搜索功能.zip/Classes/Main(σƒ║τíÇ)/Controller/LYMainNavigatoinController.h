//
//  LYMainNavigatoinController.h
//  ITSNS
//
//  Created by Ivan on 16/1/9.
//  Copyright © 2016年 Ivan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LYMainNavigatoinController : UINavigationController

@end
