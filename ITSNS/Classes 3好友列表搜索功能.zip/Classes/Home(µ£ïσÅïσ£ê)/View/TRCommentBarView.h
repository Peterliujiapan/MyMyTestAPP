//
//  TRCommentBarView.h
//  ITSNS
//
//  Created by tarena on 16/6/29.
//  Copyright © 2016年 Ivan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "YYTextView.h"
@interface TRCommentBarView : UIView
@property (strong, nonatomic) YYTextView *commentTV;

@end
