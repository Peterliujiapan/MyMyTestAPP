//
//  TRCommentBarView.m
//  ITSNS
//
//  Created by tarena on 16/6/29.
//  Copyright © 2016年 Ivan. All rights reserved.
//

#import "TRCommentBarView.h"

@implementation TRCommentBarView

-(void)awakeFromNib{
    
    self.commentTV = [[YYTextView alloc]initWithFrame:CGRectMake(106, 5, 215, 31)];
    
    self.commentTV.backgroundColor = LYGrayColor;
    [self addSubview:self.commentTV];
    
    
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
