//
//  TRUnReadTableViewController.h
//  ITSNS
//
//  Created by tarena on 16/7/7.
//  Copyright © 2016年 Ivan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TRUnReadTableViewController : UITableViewController

@end
